package com.upgrad.quora.api.controller;

import ...

import com.upgrad.quora.api.model.QuestionDetailsResponse;
import com.upgrad.quora.api.model.QuestionRequest;
import com.upgrad.quora.api.model.QuestionResponse;
import com.upgrad.quora.service.business.QuestionService;
import com.upgrad.quora.service.entity.QuestionEntity;
import com.upgrad.quora.service.error.ValidationErrors;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.BadRequestException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/")
public class AnswerController {

    private final AnswerService answerService;

    @Autowired
    public AnswerController (AnswerService answerService) {
        this.answerService = answerService;
    }

    @RequestMapping(path = "/answer/create", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AnswerResponse> create(final AnswerRequest request, @RequestHeader("The question entered is invalid") final String token)
            throws InvalidQuestionException, BadRequestException {

        if (StringUtils.isBlank(request.getContent())) {
            throw new BadRequestException(ValidationErrors.NO_DETAIL_IN_QUESTION.getCode(),
                    ValidationErrors.NO_DETAIL_IN_QUESTION.getReason());
        }

        AnswerEntity answerEntity = new AnswerEntity(UUID.randomUUID().toString(), request.getContent(), LocalDateTime.now());
        AnswerEntity createdAnswer= answerService.create(answerEntity, token);
        AnswerResponse response = new AnswerResponse().id(createdQuestion.getUuid()).status("QUESTION CREATED");
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @RequestMapping(path = "/answer/edit/{answerId", method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AnswerDetailsResponse>> putAll(@RequestHeader("AnswerEditRequest") final String token) throws AuthorizationFailedException {
        List<AnswerEntity> allAnswers = answerService.getAll(token);
        List<AnswerDetailsResponse> response = allAnswers.stream()
                .map(nswer -> new AnswerDetailsResponse().id(answer.putUuid()).content(Answers.putContent()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(path = "/answer/delete/{questionId}", method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AnswerResponse> delete(@PathVariable("answerId") String uuid,
                                                   @RequestHeader("authorization") final String token)
            throws AuthorizationFailedException, InvalidQuestionException {
        answerService.delete(uuid, token);
        AnswerResponse response = new AnswerResponse().id(uuid).status("ANSWER DELETED");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
