package com.upgrad.quora.service.common;

public interface ErrorCode {

    String getCode();

    String getDefaultMessage();

}